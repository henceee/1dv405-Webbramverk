module AppsHelper
end
