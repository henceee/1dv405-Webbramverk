require 'test_helper'

class AppsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
